const userModel = require('../models/productModel')
const  {uploadFile} =require("../utils/aws")

const  { isValid, isValidObjectType, isValidBody,  validString, validMobileNum, validEmail, validPwd, isValidObjectId } = require("../utils/validations")

const getProductById = async (req, res) => {
    try {
        const query = req.query

        if (Object.keys(query) != 0) {
            return res.status(400).send({ status: false, message: "Invalid params present in URL" })
        }

        const productId = req.params.productId

        if (!validator.isValidObjectId(productId)) {
            return res.status(400).send({ status: false, message: `${productId} is not valid type Product Id` });
        }

        const findProduct = await productModel.findOne({ _id: productId, isDeleted: false })
        if (!findProduct) {
            return res.status(404).send({ status: false, message: 'Product does not exists or has been deleted' })  //Validate: The Product Id is valid or not.
        }
        return res.status(200).send({ status: true, message: 'Product found successfully', data: findProduct })
    }
    catch (error) {
        console.log(err)
        res.status(500).send({ message: err.message })
    }
}


       

        const deleteProductById = async function (req, res) {
            try {
                let productId = req.params.productId;
                let result = await productModel.findOne({
                    _id: productId,
                    isDeleted: false
                });
                if (!result) return res.status(404).send({
                    status: false,
                    msg: "User data not found"
                })
                let updated = await productModel.findByIdAndUpdate({
                    _id: productId,
                    isDeleted: false
                }, {
                    isDeleted: true,
                    deletedAt: Date()
                }, {
                    new: true
                });
                res.status(200).send({
                    status: true,
                    data: "Deletion Successfull"
                });
            } catch (error) {
                res.status(500).send({
                    status: false,
                    msg: error.message
                });
            }
        };



module.exports = {getProductById ,deleteProductById}